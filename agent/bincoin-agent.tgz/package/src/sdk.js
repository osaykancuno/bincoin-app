// BinCoin Agent SDK - lets an autonomous agent (LLM, bot, script) play BinCoin on Robinhood Chain.
//
// Three ways for an agent to play:
//   mode "self"     the agent key IS the player (an EOA that joined the game)
//   mode "delegate" the agent key is an operator authorised by a human player (game.setOperator) -> *For calls
//   mode "tba"      the agent key is the operator of an NFT agent's ERC-6551 wallet -> executeAsOperator / batch
import { readFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import {
  createPublicClient,
  createWalletClient,
  defineChain,
  encodeFunctionData,
  formatEther,
  http,
  maxUint256,
  getAddress,
} from "viem";
import { privateKeyToAccount } from "viem/accounts";
import { planActions } from "./strategy.js";

const here = dirname(fileURLToPath(import.meta.url));
const ABIS = JSON.parse(readFileSync(join(here, "abis.json"), "utf8"));

export const CHAINS = {
  4663: { name: "Robinhood Chain", rpc: "https://rpc.mainnet.chain.robinhood.com" },
  46630: { name: "Robinhood Chain Testnet", rpc: "https://rpc.testnet.chain.robinhood.com" },
  31337: { name: "Localhost", rpc: "http://127.0.0.1:8545" },
};

/// Addresses come from BINCOIN_DEPLOYMENTS (path to a deployments json), or the repo's frontend/contracts book.
export function loadDeployment(chainId, file = process.env.BINCOIN_DEPLOYMENTS) {
  const candidates = [file, join(here, "..", "..", "frontend", "src", "contracts", "deployments.json"), join(here, "deployments.json")].filter(Boolean);
  for (const f of candidates) {
    if (!existsSync(f)) continue;
    const book = JSON.parse(readFileSync(f, "utf8"));
    const d = book[String(chainId)] ?? (book.chainId === chainId ? book : undefined);
    if (d) return d;
  }
  throw new Error(`No BinCoin deployment found for chain ${chainId}. Set BINCOIN_DEPLOYMENTS.`);
}

export class BinCoinAgent {
  /**
   * @param {object} o
   * @param {number} [o.chainId] 46630 testnet (default), 4663 mainnet, 31337 local
   * @param {string} [o.rpcUrl]
   * @param {`0x${string}`} o.privateKey agent key (never logged)
   * @param {"self"|"delegate"|"tba"} [o.mode]
   * @param {`0x${string}`} [o.player] the human player (delegate) or the ERC-6551 agent wallet (tba)
   */
  constructor({ chainId = 46630, rpcUrl, privateKey, mode = "self", player, deployment } = {}) {
    if (!privateKey) throw new Error("privateKey required");
    const meta = CHAINS[chainId] ?? { name: `chain ${chainId}`, rpc: rpcUrl };
    this.chain = defineChain({
      id: chainId,
      name: meta.name,
      nativeCurrency: { name: "Ether", symbol: "ETH", decimals: 18 },
      rpcUrls: { default: { http: [rpcUrl || meta.rpc] } },
    });
    this.d = deployment ?? loadDeployment(chainId);
    // keys pasted without the 0x prefix are common in .env files
    this.account = privateKeyToAccount(privateKey.startsWith("0x") ? privateKey : `0x${privateKey}`);
    this.mode = mode;
    this.player = getAddress(mode === "self" ? this.account.address : player ?? "");
    const transport = http(rpcUrl || meta.rpc, { batch: true });
    this.pub = createPublicClient({ chain: this.chain, transport });
    this.wallet = createWalletClient({ chain: this.chain, transport, account: this.account });
    this.game = { address: this.d.contracts.BinCoinGame, abi: ABIS.BinCoinGame };
    this.bin = { address: this.d.contracts.BinCoin, abi: ABIS.BinCoin };
    this.vault = { address: this.d.contracts.BinVault, abi: ABIS.BinVault };
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Reads
  // ---------------------------------------------------------------------------------------------------------------
  async read(c, functionName, args = []) {
    return this.pub.readContract({ ...c, functionName, args });
  }

  /// Everything an agent needs to decide its next move, in plain JSON-friendly values.
  async status() {
    const p = this.player;
    const [stats, types, facilities, player, pending, rates, installed, cooldown, bal, allowance, eth] = await Promise.all([
      this.read(this.game, "networkStats"),
      this.read(this.game, "getMinerTypes"),
      this.read(this.game, "getFacilities"),
      this.read(this.game, "players", [p]),
      this.read(this.game, "pendingRewards", [p]),
      this.read(this.game, "playerRates", [p]),
      this.read(this.game, "installedMiners", [p]),
      this.read(this.game, "timeUntilNextUpgrade", [p]),
      this.read(this.bin, "balanceOf", [p]),
      this.read(this.bin, "allowance", [p, this.game.address]),
      this.pub.getBalance({ address: p }),
    ]);
    // 0 = Chainlink unavailable and no fallback: ETH-priced actions are on hold (networkStats never reverts)
    const ethUsd = stats.ethUsd;
    let delegation;
    if (this.mode === "delegate") {
      const [expiry, binAllowance] = await this.read(this.game, "delegations", [p, this.account.address]);
      delegation = { expiry: Number(expiry), binAllowance };
    }
    let operatorActive;
    let operatorBudget;
    let crossChain;
    if (this.mode === "tba") {
      const acct = { address: p, abi: ABIS.BinAgentAccount };
      operatorActive = await this.read(acct, "isActiveOperator", [this.account.address]);
      // daily damage limit set by the NFT holder (absent on wallets deployed before it existed)
      const left = await this.read(acct, "operatorBudgetLeft").catch(() => undefined);
      if (left) operatorBudget = { binLeft: left[0], ethLeft: left[1] };
      // an Ethereum NFT's wallet: its owner is synced through the native bridge (wallets of older deployments: false)
      crossChain = await this.read(acct, "isCrossChain").catch(() => false);
    }
    const tier = Number(player[0]);
    return {
      mode: this.mode,
      agent: this.account.address,
      player: p,
      joined: tier > 0,
      network: {
        emissionPerSec: stats.emissionRate,
        era: Number(stats.era),
        nextHalvingAt: Number(stats.nextHalvingAt),
        totalHashrate: stats.totalHashrate,
        players: Number(stats.playerCount),
        electricityBps: stats.electricityBps,
        totalPower: stats.totalPower,
        joinFeeEth: stats.joinFeeEth,
        ethUsd,
      },
      facility: tier > 0 ? { tier, ...facilities[tier - 1] } : null,
      nextFacility:
        tier > 0 && facilities[tier]
          ? { tier: tier + 1, ...facilities[tier], costEth: facilities[tier].costUsd === 0n ? 0n : ethUsd > 0n ? await this.read(this.game, "facilityPriceEth", [BigInt(tier + 1)]) : null }
          : null,
      agentEthBalance: this.mode === "self" ? eth : await this.pub.getBalance({ address: this.account.address }),
      upgradeCooldown: Number(cooldown),
      hashrate: player[5],
      powerUsed: Number(player[2]),
      minerCount: Number(player[1]),
      pending,
      rates: { grossPerSec: rates[0], billPerSec: rates[1], netPerSec: rates[2] },
      binBalance: bal,
      binAllowance: allowance,
      ethBalance: eth,
      installed,
      minerTypes: types.map((t, i) => ({ id: i + 1, ...t })),
      delegation,
      operatorActive,
      operatorBudget,
      crossChain,
    };
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Writes - every action is routed according to the mode
  // ---------------------------------------------------------------------------------------------------------------
  /// Build the call that performs `fn` on the game for the player, as seen from the agent key.
  gameCall(fn, args = [], value = 0n) {
    if (this.mode === "delegate") {
      const forFn = {
        claim: "claimFor",
        buyMiner: "buyMinerFor",
        buyMinerWithEth: "buyMinerWithEthFor",
        upgradeFacility: "upgradeFacilityFor",
        sellMiner: "sellMinerFor",
        removeMiner: "removeMinerFor",
        installMiner: "installMinerFor",
        moveMiner: "moveMinerFor",
      }[fn];
      if (!forFn) throw new Error(`${fn} is not available to delegated operators`);
      return { to: this.game.address, data: encodeFunctionData({ abi: this.game.abi, functionName: forFn, args: [this.player, ...args] }), value };
    }
    return { to: this.game.address, data: encodeFunctionData({ abi: this.game.abi, functionName: fn, args }), value };
  }

  approveCall(spender = this.game.address) {
    return { to: this.bin.address, data: encodeFunctionData({ abi: this.bin.abi, functionName: "approve", args: [spender, maxUint256] }), value: 0n };
  }

  /// Sends calls. In TBA mode they are batched atomically through the agent wallet (one transaction).
  async send(calls, { dryRun = false } = {}) {
    if (calls.length === 0) return [];
    if (dryRun) return calls.map((c) => ({ dryRun: true, ...c }));
    if (this.mode === "tba") {
      const acct = { address: this.player, abi: ABIS.BinAgentAccount };
      const req =
        calls.length === 1
          ? { ...acct, functionName: "executeAsOperator", args: [calls[0].to, calls[0].value, calls[0].data] }
          : { ...acct, functionName: "executeBatchAsOperator", args: [calls.map((c) => ({ to: c.to, value: c.value, data: c.data }))] };
      const { request } = await this.pub.simulateContract({ ...req, account: this.account }).catch(explain);
      const hash = await this.wallet.writeContract(request);
      return [await this.wait(hash)];
    }
    const out = [];
    for (const c of calls) {
      await this.pub.call({ account: this.account, to: c.to, data: c.data, value: c.value }).catch(explain); // simulate -> readable revert
      const hash = await this.wallet.sendTransaction({ to: c.to, data: c.data, value: c.value });
      out.push(await this.wait(hash));
    }
    return out;
  }

  async wait(hash) {
    const r = await this.pub.waitForTransactionReceipt({ hash });
    if (r.status !== "success") throw new Error(`transaction ${hash} reverted`);
    return { hash, block: Number(r.blockNumber), gasUsed: r.gasUsed };
  }

  // convenience actions
  async join(referrer) {
    if (this.mode === "delegate") throw new Error("a delegated operator cannot join for a player");
    // an NFT agent wallet only lets its operator join with the referrer its holder set (at mint, or later)
    if (!referrer && this.mode === "tba")
      referrer = await this.read({ address: this.player, abi: ABIS.BinAgentAccount }, "joinReferrer").catch(() => undefined);
    referrer ??= "0x0000000000000000000000000000000000000000";
    const fee = await this.read(this.game, "joinFeeEth");
    return this.send([this.gameCall("join", [referrer], (fee * 101n) / 100n)]);
  }
  claim(opts) {
    return this.send([this.gameCall("claim")], opts);
  }
  async buyMiner(typeId, x, y, opts) {
    const calls = [];
    if (this.mode !== "delegate" && (await this.read(this.bin, "allowance", [this.player, this.game.address])) < 10n ** 30n) calls.push(this.approveCall());
    calls.push(this.gameCall("buyMiner", [BigInt(typeId), BigInt(x), BigInt(y)]));
    return this.send(calls, opts);
  }
  async upgradeFacility(opts) {
    const calls = [];
    if (this.mode !== "delegate" && (await this.read(this.bin, "allowance", [this.player, this.game.address])) < 10n ** 30n) calls.push(this.approveCall());
    const s = await this.status();
    calls.push(this.gameCall("upgradeFacility", [], ((s.nextFacility?.costEth ?? 0n) * 101n) / 100n));
    return this.send(calls, opts);
  }
  sellMiner(id, opts) {
    return this.send([this.gameCall("sellMiner", [BigInt(id)])], opts);
  }

  // ---------------------------------------------------------------------------------------------------------------
  // Autonomy
  // ---------------------------------------------------------------------------------------------------------------
  /// Decide (pure function over status) what to do next.
  async plan(policy = {}) {
    const s = await this.status();
    return { status: s, actions: planActions(s, policy) };
  }

  /// One autonomous step: plan, then execute. In TBA mode the whole plan lands in a single atomic transaction.
  async autoStep(policy = {}, { dryRun = false } = {}) {
    const { status, actions } = await this.plan(policy);
    if (!status.joined) return { actions: [{ type: "join-required", reason: "player has not joined" }], results: [] };
    const calls = [];
    let needsApprove = this.mode !== "delegate" && status.binAllowance < 10n ** 30n;
    for (const a of actions) {
      if ((a.type === "buy" || a.type === "upgrade") && needsApprove) {
        calls.push(this.approveCall());
        needsApprove = false;
      }
      if (a.type === "claim") calls.push(this.gameCall("claim"));
      if (a.type === "sell") calls.push(this.gameCall("sellMiner", [BigInt(a.minerId)]));
      if (a.type === "upgrade") calls.push(this.gameCall("upgradeFacility", [], ((status.nextFacility?.costEth ?? 0n) * 101n) / 100n));
      if (a.type === "buy") calls.push(this.gameCall("buyMiner", [BigInt(a.typeId), BigInt(a.x), BigInt(a.y)]));
    }
    const results = calls.length ? await this.send(calls, { dryRun }) : [];
    return { actions, results };
  }
}

/// Surface the decoded revert reason instead of a generic RPC error
function explain(e) {
  const decoded = e?.walk?.((x) => x?.data?.errorName);
  if (decoded) throw new Error(`reverted: ${decoded.data.errorName}(${(decoded.data.args ?? []).join(", ")})`);
  const reason = /reverted with (?:custom error|reason string) '([^']+)'/.exec(e?.details ?? e?.message ?? "")?.[1];
  throw new Error(reason ? `reverted: ${reason}` : e?.shortMessage ?? String(e));
}

/// JSON-safe view (bigints -> strings, BIN amounts -> decimal strings where useful)
export function toJson(v) {
  return JSON.parse(JSON.stringify(v, (_, x) => (typeof x === "bigint" ? x.toString() : x)));
}

export const fmtBin = (v) => Number(formatEther(v)).toLocaleString("en-US", { maximumFractionDigits: 4 });
export { ABIS };
