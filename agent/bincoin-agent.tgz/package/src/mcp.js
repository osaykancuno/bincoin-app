#!/usr/bin/env node
// BinCoin MCP server: exposes the game as tools so Claude (or any MCP client) can play as an autonomous miner.
//
// Settings come from the environment or from the agent env file written by `bincoin init` (~/.bincoin/agent.env).
// Claude Code:    claude mcp add bincoin -- bincoin-mcp
// Claude Desktop: "mcpServers": { "bincoin": { "command": "bincoin-mcp" } } in claude_desktop_config.json
//
// Safety: in "delegate" or "tba" mode the key can only play (enforced on-chain); it can never withdraw funds.
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";
import { parseEther } from "viem";
import { BinCoinAgent, toJson } from "./sdk.js";
import { DESTINATION_CHAIN_ID, ORIGINS, fund } from "./bridge.js";
import { planActions, DEFAULT_POLICY } from "./strategy.js";
import { loadEnv } from "./env.js";

loadEnv();
const agent = new BinCoinAgent({
  chainId: Number(process.env.BINCOIN_CHAIN_ID ?? 46630),
  rpcUrl: process.env.BINCOIN_RPC_URL,
  privateKey: process.env.BINCOIN_PRIVATE_KEY,
  mode: process.env.BINCOIN_MODE ?? "self",
  player: process.env.BINCOIN_PLAYER,
});

const server = new McpServer({ name: "bincoin", version: "1.6.0" });
const ok = (data) => ({ content: [{ type: "text", text: JSON.stringify(toJson(data), null, 2) }] });
const fail = (e) => ({ isError: true, content: [{ type: "text", text: e.shortMessage ?? e.message ?? String(e) }] });
const guard = (fn) => async (args) => {
  try {
    return ok(await fn(args ?? {}));
  } catch (e) {
    return fail(e);
  }
};

server.tool(
  "bincoin_status",
  "Full state of the agent's BinCoin operation on Robinhood Chain: network emission and hashrate, facility, installed miners, pending BIN, net BIN/day after electricity, balances. BIN amounts are wei strings (18 decimals).",
  {},
  guard(() => agent.status())
);

server.tool(
  "bincoin_rules",
  "How BinCoin works (economics an agent must understand before acting).",
  {},
  guard(async () => ({
    emission: "21M BIN max, per-second emission (0.333 BIN/s in year 1), halving every year (365 days), split by hashrate share",
    launch: "1,000 Boot Disks (Kind = Boot Disk in the BinCoin collection) are minted on OpenSea's drop page before mining starts (SeaDrop, 2 per wallet; 10% to OpenSea, 90% to BinGenesis, nothing to the team). Mining starts 24h after the last disk (BootDisksSoldOut), at the latest at latestStart, for everyone at once. insertDisk(diskId, referrer) burns a disk and mints its Genesis Miner (200 H/s, 1 W, the disk's number, no per-player limit): a new player joins with it (no fee, installed, genesisOf = Genesis rank); a joined player gets it in the wallet. Genesis Day (BinGenesis): during the first 24h of mining (or 24h from a later first deposit: windowEnds) anyone may deposit mined BIN (final); then the team opens the market (opener; anyone 24h later: openableByAnyoneAt): open() pays half the Boot Disk ETH to depositors pro-rata (one price for all) and puts the other half + all deposited BIN into the BIN/WETH Uniswap v2 pool at that price, LP burned",
    electricity: "20% of the emission is billed by watts; a miner pays off only above the break-even H/W (breakEvenEfficiency() = 20% x network average H/W). Below it, it LOWERS the facility's net rewards -> sell or uninstall it. The rate moves at most 5 points per week",
    miners: "bought with BIN: 75% burned, 25% stored as the exact refund you get when selling it back; miners are NFTs, tradable when uninstalled",
    facilities: "9 tiers; upgrades cost BIN (100% burned) with a 24h cooldown; slots and watts limit what you can install",
    claimFee: "2.5% of every claim is never minted: it stays with the Reserve (no referrer earns BIN)",
    referrals: "a referrer earns 10% of the ETH their invitees pay (withdrawReferralEth). An invitee who reaches facility tier 3 (Warehouse) counts as a qualified friend (qualifiedReferrals, prestige only: ranks Scout 1, Recruiter 3, Ambassador 10, Legend 25)",
    nfts: "miners, AI agents and Boot Disks are ONE ERC-721 collection, BinCoin (contract BinMiner; trait Kind = Miner / Agent / Boot Disk; minersOfOwner / agentsOfOwner / disksOfOwner), with fully on-chain metadata: pixel-art image + animation, traits (model, stats, serial / limited edition, halving era), collection page (contractURI), ERC-4906 refresh and ERC-5192 lock events (installed and starter miners cannot be listed). 5% royalty on miner sales to the Reserve, none on agents. Secondary market: an uninstalled miner sells for more than its 25% refund and less than the shop price; sold-out limited editions only trade there. Era Editions: one commemorative miner per halving era ($5, one per player, no supply cap during its era, retired at the next halving). No ETH price anywhere is above $25",
    reserve: "ETH revenue backs BIN in a vault (ETH, WETH and, where listed, ten Robinhood Stock Tokens: SPY, QQQ, SGOV, NVDA, AAPL, MSFT, GOOGL, AMZN, META, TSLA; capped at 10% each / 40% total); anyone can burn BIN to redeem a pro-rata share in kind. Stock Tokens are debt securities restricted for US persons",
    agentMint: "a new agent NFT (mint on the BinCoin collection) costs mintFeeEth() = two join fees, 100% to the Reserve; any other NFT can get a mining wallet for free through the ERC-6551 registry",
    agentLimits: "an NFT agent wallet charges every operator call against a daily BIN/ETH budget set by the holder (operatorBudgetLeft); a miner sale counts at its price minus the refund; the holder can lock the wallet for a sale (lockedUntil)",
    market: "BinMarket, the in-dApp NFT market: ownerless, no fee, no custody; fixed-price ETH listings (list after setApprovalForAll, buy pays exactly the price, cancel, liveListings); 5% of miner sales to the Reserve, 0 on agents; installed/starter miners cannot be listed; an agent is listable only while its wallet is locked until the listing expires",
    open: "free like Bitcoin: code MIT, art/logo/name/texts public domain (CC0), no trademark; anyone may fork, run or build on BinCoin without permission. The BIN token has no owner, no pause, no blacklist and no transfer fee; it is a plain ERC-20 (18 decimals, permit) with its logo and description on-chain (contractURI)",
    governance: "on mainnet a 48h public timelock owns the contracts: rule changes are announced on-chain 2 days ahead; a guardian can only pause purchases, claims and sales never pause",
    defaultPolicy: DEFAULT_POLICY,
  }))
);

server.tool(
  "bincoin_plan",
  "Ask the built-in strategy what to do next (no transaction). Returns ordered actions with reasons.",
  {
    minClaimBin: z.number().optional().describe("claim only if at least this much BIN is pending"),
    reserveBin: z.number().optional().describe("keep at least this BIN unspent"),
    maxPaybackDays: z.number().optional().describe("ignore miners with a longer payback"),
    allowEthSpend: z.boolean().optional().describe("allow ETH-priced facility upgrades (tiers 5-9)"),
  },
  guard(async (p) => planActions(await agent.status(), p))
);

server.tool(
  "bincoin_auto_step",
  "Execute one autonomous step of the strategy: claim, sell unprofitable miners, buy the best-payback miners that fit, upgrade the facility if it is the bottleneck. In tba mode everything is one atomic transaction.",
  {
    dryRun: z.boolean().optional(),
    minClaimBin: z.number().optional(),
    reserveBin: z.number().optional(),
    maxPaybackDays: z.number().optional(),
    allowEthSpend: z.boolean().optional(),
  },
  guard(async ({ dryRun, ...policy }) => agent.autoStep(policy, { dryRun }))
);

server.tool("bincoin_join", "Join the game (pays the USD-priced entry fee in ETH). Not available in delegate mode.", { referrer: z.string().optional() }, guard(({ referrer }) => agent.join(referrer)));
server.tool("bincoin_claim", "Claim pending BIN to the player.", {}, guard(() => agent.claim()));
server.tool(
  "bincoin_buy_miner",
  "Buy a BIN-priced miner type and install it at grid cell (x, y). Use bincoin_status to see minerTypes and free cells.",
  { typeId: z.number().int(), x: z.number().int(), y: z.number().int() },
  guard(({ typeId, x, y }) => agent.buyMiner(typeId, x, y))
);
server.tool("bincoin_upgrade_facility", "Upgrade to the next facility tier (BIN cost is burned, 24h cooldown; tiers 5-9 also cost a USD-priced amount of ETH).", {}, guard(() => agent.upgradeFacility()));
server.tool(
  "bincoin_sell_miner",
  "Sell an installed or wallet miner back for its reserved BIN refund (the NFT is burned).",
  { minerId: z.string() },
  guard(({ minerId }) => agent.sellMiner(minerId))
);

// an AI may move at most this much ETH per call between chains (BINCOIN_FUND_MAX_ETH), always to its own wallets
const FUND_MAX = parseEther(process.env.BINCOIN_FUND_MAX_ETH || "0.05");
server.tool(
  "bincoin_fund",
  `Bring ETH from another chain to Robinhood Chain mainnet through the Relay bridge (seconds, a few cents). The AI key pays from its own balance on the origin chain. The ETH can only go to the AI key (gas) or to the player wallet: never elsewhere. Max ${process.env.BINCOIN_FUND_MAX_ETH || "0.05"} ETH per call. Use quoteOnly first to see the fee.`,
  {
    from: z.enum(Object.keys(ORIGINS)).describe("origin chain where the AI key holds ETH"),
    amountEth: z.number().positive().describe("ETH to send from the origin chain"),
    to: z.enum(["agent", "player"]).optional().describe("agent = the AI key, for gas (default); player = the wallet that plays (join fee, ETH upgrades)"),
    quoteOnly: z.boolean().optional(),
  },
  guard(async ({ from, amountEth, to = "agent", quoteOnly }) => {
    if (agent.chain.id !== DESTINATION_CHAIN_ID) throw new Error("cross-chain funding works on Robinhood Chain mainnet only; on testnet use the faucet");
    const amount = parseEther(String(amountEth));
    if (amount > FUND_MAX) throw new Error(`above the ${process.env.BINCOIN_FUND_MAX_ETH || "0.05"} ETH limit per call (BINCOIN_FUND_MAX_ETH)`);
    return fund({ account: agent.account, from, recipient: to === "agent" ? agent.account.address : agent.player, amount, rpcUrl: process.env.BINCOIN_FROM_RPC_URL, dryRun: !!quoteOnly });
  })
);

await server.connect(new StdioServerTransport());
