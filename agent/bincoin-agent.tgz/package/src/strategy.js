// Deterministic BinCoin strategy: a pure function from status to actions, so it is testable and explainable.
// Agents (or LLMs through MCP) can use it as-is, tune the policy, or just read its reasoning.
const DAY = 86400;
const POOL_FEE = 0.025; // 2.5% of every claim is never minted (it stays with the Reserve)

export const DEFAULT_POLICY = {
  minClaimBin: 1, // claim when at least this much is pending (or when it is needed to afford the plan)
  reserveBin: 0, // never spend below this balance
  maxPaybackDays: 120, // ignore miners that would take longer than this to repay their non-refundable cost
  pruneUnprofitable: true, // sell miners whose electricity bill exceeds their rewards
  allowUpgrade: true,
  allowEthSpend: false, // high facility tiers also cost ETH: off by default, an agent never spends ETH unless allowed
};

const num = (b) => Number(b) / 1e18;

/// Net BIN/day a miner would earn if added to the network now (includes its own dilution).
// electricity = electricityBps of the emission, split by the watts every miner draws
export function minerNetPerDay(status, m) {
  const n = status.network;
  const rate = num(n.emissionPerSec);
  const H = Number(n.totalHashrate) + Number(m.hashrate);
  const P = Number(n.totalPower) + Number(m.power);
  const gross = H > 0 ? (rate * Number(m.hashrate)) / H : 0;
  const bill = P > 0 ? (rate * (Number(n.electricityBps) / 10000) * Number(m.power)) / P : 0;
  return (gross - bill) * DAY;
}

/// Net BIN/day an installed miner contributes right now.
export function installedNetPerDay(status, m) {
  const n = status.network;
  const rate = num(n.emissionPerSec);
  const H = Number(n.totalHashrate);
  const P = Number(n.totalPower);
  const gross = H > 0 ? (rate * Number(m.hashrate)) / H : 0;
  const bill = P > 0 ? (rate * (Number(n.electricityBps) / 10000) * Number(m.power)) / P : 0;
  return (gross - bill) * DAY;
}

function freeCells(facility, installed) {
  const taken = new Set(installed.map((m) => `${m.x}:${m.y}`));
  const out = [];
  for (let y = 0; y < facility.gridH; y++) for (let x = 0; x < facility.gridW; x++) if (!taken.has(`${x}:${y}`)) out.push({ x, y });
  return out;
}

export function planActions(status, policy = {}) {
  const P = { ...DEFAULT_POLICY, ...policy };
  if (!status.joined) return [{ type: "join", reason: "not in the game yet: join with ETH to receive a Garage and a starter miner" }];

  const actions = [];
  let installed = [...status.installed];
  // pending is only spendable after the 2.5% claim fee
  let budget = num(status.binBalance) + num(status.pending) * (1 - POOL_FEE) - P.reserveBin;
  if (status.delegation) budget = Math.min(budget, num(status.delegation.binAllowance));
  // NFT agent wallet: what the holder lets the AI key spend today
  if (status.operatorBudget) budget = Math.min(budget, num(status.operatorBudget.binLeft));
  let power = status.powerUsed;
  let slots = status.minerCount;
  let facility = status.facility;

  // 1. claim: rewards only compound once claimed
  if (num(status.pending) >= P.minClaimBin) actions.push({ type: "claim", amount: num(status.pending), reason: "compound pending rewards" });
  else budget -= num(status.pending) * (1 - POOL_FEE);

  // no new BIN right now: before the announced start, or after the last era (~30 years in). Every miner would look
  // unprofitable, so never sell or buy on that: just collect what is owed and wait.
  if (BigInt(status.network.emissionPerSec ?? 0n) === 0n) {
    actions.push({ type: "wait", reason: Number(status.network.era ?? 0) === 0 ? "mining has not started yet (it begins at the announced start time)" : "emission is over: every BIN has been mined" });
    return actions;
  }

  // 2. prune miners the electricity bill has made worthless (difficulty went up)
  if (P.pruneUnprofitable) {
    for (const m of installed) {
      if (!m.sellable) continue;
      const net = installedNetPerDay(status, m);
      if (net <= 0) {
        // a delegated operator's sale draws the miner's BIN price from the delegation cap (anti-liquidation guard);
        // an NFT agent wallet charges the same price, minus the refund that comes back, to the daily budget
        if (status.delegation || status.operatorBudget) {
          const typeCost = num(status.minerTypes.find((t) => BigInt(t.id) === BigInt(m.typeId))?.costBin ?? 0n);
          const charge = status.delegation ? typeCost : Math.max(0, typeCost - num(m.refund));
          if (charge > budget) {
            actions.push({ type: "wait", reason: `${m.name} #${m.id} is unprofitable but selling it needs ${charge} BIN of ${status.delegation ? "delegation cap" : "today's budget"}` });
            continue;
          }
          budget -= charge;
        }
        actions.push({ type: "sell", minerId: m.id.toString(), name: m.name, refund: num(m.refund), reason: `unprofitable: ${net.toFixed(4)} BIN/day after electricity` });
        // the refund lands in the wallet, but it does not raise a delegated operator's cap or the daily budget
        if (!status.delegation && !status.operatorBudget) budget += num(m.refund);
        power -= Number(m.power);
        slots -= 1;
      }
    }
    const sold = new Set(actions.filter((a) => a.type === "sell").map((a) => a.minerId));
    installed = installed.filter((m) => !sold.has(m.id.toString()));
  }

  // candidate miners ranked by payback of their non-refundable (burned) cost
  const burn = 0.75;
  const candidates = status.minerTypes
    .filter((t) => t.active && t.costBin > 0n && !(t.maxSupply > 0 && t.minted >= t.maxSupply))
    .map((t) => {
      const netDay = minerNetPerDay(status, t);
      const cost = num(t.costBin);
      return { t, netDay, cost, payback: netDay > 0 ? (cost * burn) / netDay : Infinity };
    })
    .filter((c) => c.payback <= P.maxPaybackDays)
    .sort((a, b) => a.payback - b.payback);

  // 3. buy the best-payback miners that fit, as long as the budget allows
  let cells = freeCells(facility, installed);
  const perType = {};
  for (const m of installed) perType[m.typeId] = (perType[m.typeId] ?? 0) + 1;
  let progress = true;
  while (progress) {
    progress = false;
    for (const c of candidates) {
      if (c.cost > budget || cells.length === 0 || slots + 1 > facility.maxMiners) continue;
      if (power + c.t.power > facility.power) continue;
      if (c.t.maxPerPlayer && (perType[c.t.id] ?? 0) >= c.t.maxPerPlayer) continue;
      const cell = cells.shift();
      actions.push({ type: "buy", typeId: c.t.id, name: c.t.name, x: cell.x, y: cell.y, cost: c.cost, reason: `best payback ${c.payback.toFixed(1)}d (${c.netDay.toFixed(3)} BIN/day)` });
      budget -= c.cost;
      power += c.t.power;
      slots += 1;
      perType[c.t.id] = (perType[c.t.id] ?? 0) + 1;
      progress = true;
      break;
    }
  }

  // 4. upgrade the facility when it is the bottleneck (full slots or power) and affordable
  const best = candidates[0];
  const blocked = best && (slots + 1 > facility.maxMiners || power + best.t.power > facility.power || cells.length === 0);
  if (P.allowUpgrade && status.nextFacility && status.upgradeCooldown === 0 && blocked) {
    const cost = num(status.nextFacility.costBin);
    const eth = status.nextFacility.costEth ?? 0n;
    // who pays the ETH: the NFT agent's wallet in tba mode (within its daily operator budget), the AI key otherwise
    const payerEth = status.mode === "tba" ? status.ethBalance : status.agentEthBalance;
    const withinBudget = status.mode !== "tba" || !status.operatorBudget || status.operatorBudget.ethLeft >= (eth * 101n) / 100n;
    const ethOk = eth === 0n || (P.allowEthSpend && (payerEth ?? 0n) > (eth * 102n) / 100n && withinBudget);
    if (status.nextFacility.costEth === null) {
      actions.push({ type: "wait", reason: "the ETH price feed is unavailable: ETH-priced upgrades are on hold" });
    } else if (cost <= budget && ethOk) {
      actions.push({ type: "upgrade", to: status.nextFacility.name, cost, eth: num(eth), reason: "facility is the bottleneck (slots/power)" });
    } else if (cost <= budget && !ethOk) {
      actions.push({ type: "wait", reason: `next facility needs ${num(eth).toFixed(5)} ETH too: set allowEthSpend and fund the agent` });
    }
  }

  if (actions.length === 0) actions.push({ type: "wait", reason: "nothing profitable to do right now: keep mining" });
  return actions;
}
