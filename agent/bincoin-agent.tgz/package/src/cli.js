#!/usr/bin/env node
// bincoin - command line for agents and humans.
//
//   bincoin init                       # create the AI's own key (saved in ~/.bincoin/agent.env), print its address
//   bincoin init --mode delegate --player 0xYou   # after authorising it in the dApp (Agents page)
//   bincoin status                     # what the AI sees
//   bincoin plan                       # what the strategy would do now (no transaction)
//   bincoin auto --interval 300        # play forever: claim, compound, upgrade, prune
//   bincoin join [referrer] | claim | buy <typeId> [x y] | upgrade | sell <minerId> | address
//   bincoin fund --from base --amount 0.003 [--to agent|player] [--quote]
//                                      # bring ETH from another chain to Robinhood Chain (mainnet, via Relay)
//
// Settings (environment variables, or the agent env file written by `init`): BINCOIN_PRIVATE_KEY,
//      BINCOIN_CHAIN_ID (46630 testnet | 4663 mainnet | 31337 local), BINCOIN_RPC_URL,
//      BINCOIN_MODE (self | delegate | tba), BINCOIN_PLAYER (your wallet in delegate mode, the agent wallet in tba),
//      BINCOIN_DEPLOYMENTS (path to a deployments json), BINCOIN_ENV_FILE (where `init` keeps the settings),
//      BINCOIN_FROM_RPC_URL (RPC of the origin chain for `fund`; a public one by default)
import { formatEther, getAddress, parseEther } from "viem";
import { generatePrivateKey, privateKeyToAccount } from "viem/accounts";
import { BinCoinAgent, fmtBin, toJson } from "./sdk.js";
import { planActions } from "./strategy.js";
import { ENV_FILE, loadEnv, readEnvFile, writeEnvFile } from "./env.js";
import { DESTINATION_CHAIN_ID, ORIGINS, fund } from "./bridge.js";

const fromShell = process.env.BINCOIN_PRIVATE_KEY;
loadEnv();

const args = process.argv.slice(2);
const cmd = args[0] ?? "status";
const flag = (name, def) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] ?? true : def;
};

function agent() {
  return new BinCoinAgent({
    chainId: Number(process.env.BINCOIN_CHAIN_ID ?? 46630),
    rpcUrl: process.env.BINCOIN_RPC_URL,
    privateKey: process.env.BINCOIN_PRIVATE_KEY,
    mode: process.env.BINCOIN_MODE ?? "self",
    player: process.env.BINCOIN_PLAYER,
  });
}

/// the AI pays its own gas: warn before it gets stuck
const LOW_GAS = parseEther("0.0002");
function gasWarning(s) {
  const now = Date.now() / 1000;
  if (s.mode === "delegate" && (!s.delegation || s.delegation.expiry < now))
    console.log(`! not authorised: in the dApp open Agents -> "Let an AI play my account" and paste ${s.agent}`);
  if (s.mode === "tba" && s.operatorActive === false)
    console.log(`! not plugged in: in the dApp open Agents, then "Plug in your AI" on the agent's card, and paste ${s.agent}`);
  if (s.mode !== "self" && s.agentEthBalance < LOW_GAS)
    console.log(
      `! the AI key has ${fmtBin(s.agentEthBalance)} ETH for gas: send a little ETH (0.001 lasts thousands of moves) to ${s.agent}` +
        (Number(process.env.BINCOIN_CHAIN_ID ?? 46630) === DESTINATION_CHAIN_ID ? `, or bring it from another chain: bincoin fund --from base --amount 0.002` : "")
    );
}

function init() {
  const file = readEnvFile();
  const values = {};
  const reuse = fromShell || file.BINCOIN_PRIVATE_KEY;
  if (!reuse) values.BINCOIN_PRIVATE_KEY = generatePrivateKey();
  if (flag("chain")) values.BINCOIN_CHAIN_ID = String(flag("chain"));
  else if (!file.BINCOIN_CHAIN_ID) values.BINCOIN_CHAIN_ID = "46630";
  if (flag("mode")) {
    if (!["self", "delegate", "tba"].includes(flag("mode"))) throw new Error("--mode must be self, delegate or tba");
    values.BINCOIN_MODE = flag("mode");
  }
  if (flag("player")) values.BINCOIN_PLAYER = getAddress(flag("player"));
  writeEnvFile(values);
  const key = reuse || values.BINCOIN_PRIVATE_KEY;
  const address = privateKeyToAccount(key.startsWith("0x") ? key : `0x${key}`).address;
  const s = { ...file, ...values };
  console.log(`${reuse ? "Using the AI key you already have" : "Created a new key for your AI"}. Settings: ${ENV_FILE}`);
  console.log("(keep that file private: it is the AI's wallet; the key is never printed)\n");
  console.log(`  AI address: ${address}\n`);
  if (!s.BINCOIN_MODE || !s.BINCOIN_PLAYER) {
    console.log("Next:");
    console.log("  1. Open the BinCoin dApp -> Agents, pick how the AI plays and paste the address above.");
    console.log("  2. Send a little ETH for gas to that address (0.001 ETH lasts thousands of moves).");
    console.log("  3. Run the two commands the dApp shows at the end, e.g.");
    console.log("       bincoin init --mode delegate --player 0xYourWallet");
    console.log("       bincoin auto");
  } else {
    console.log(`Ready: mode ${s.BINCOIN_MODE}, playing for ${s.BINCOIN_PLAYER} on chain ${s.BINCOIN_CHAIN_ID}. Start with: bincoin auto`);
  }
}

function printStatus(s) {
  console.log(`agent   ${s.agent}  (mode: ${s.mode})`);
  console.log(`player  ${s.player}  ${s.joined ? "" : "- NOT JOINED"}`);
  if (s.delegation?.expiry) console.log(`delegation  ${fmtBin(s.delegation.binAllowance)} BIN left, until ${new Date(s.delegation.expiry * 1000).toISOString()}`);
  if (s.operatorActive !== undefined) console.log(`operator active: ${s.operatorActive}`);
  if (s.crossChain) console.log("NFT on Ethereum: its owner is synced through Robinhood Chain's bridge; withdrawals are sent from Ethereum");
  if (s.mode !== "self") console.log(`gas     ${fmtBin(s.agentEthBalance)} ETH on the AI key`);
  gasWarning(s);
  console.log(`network era ${s.network.era + 1} · ${fmtBin(s.network.emissionPerSec * 86400n)} BIN/day · hashrate ${s.network.totalHashrate} · ${s.network.players} players`);
  if (!s.joined) return console.log(`join fee ${fmtBin(s.network.joinFeeEth)} ETH`);
  console.log(`facility ${s.facility.name} (tier ${s.facility.tier}) · ${s.minerCount}/${s.facility.maxMiners} slots · ${s.powerUsed}/${s.facility.power} W`);
  console.log(`hashrate ${s.hashrate} · net ${fmtBin(s.rates.netPerSec * 86400n)} BIN/day (electricity -${fmtBin(s.rates.billPerSec * 86400n)})`);
  console.log(`pending ${fmtBin(s.pending)} BIN · wallet ${fmtBin(s.binBalance)} BIN · ${fmtBin(s.ethBalance)} ETH`);
  for (const m of s.installed) console.log(`  #${m.id} ${m.name} @(${m.x},${m.y}) ${m.hashrate} H/s ${m.power} W`);
}

async function main() {
  if (cmd === "init") return init();
  if (!process.env.BINCOIN_PRIVATE_KEY) throw new Error("No AI key yet: run `bincoin init` first (or set BINCOIN_PRIVATE_KEY).");
  if (cmd === "address") {
    const k = process.env.BINCOIN_PRIVATE_KEY;
    return console.log(privateKeyToAccount(k.startsWith("0x") ? k : `0x${k}`).address);
  }
  const a = agent();
  switch (cmd) {
    case "status":
      return flag("json") ? console.log(JSON.stringify(toJson(await a.status()), null, 2)) : printStatus(await a.status());
    case "plan": {
      const s = await a.status();
      for (const x of planActions(s, policy())) console.log(`- ${x.type}${x.name ? ` ${x.name}` : ""}: ${x.reason}`);
      return;
    }
    case "join":
      return console.log(await a.join(args[1]));
    case "claim":
      return console.log(await a.claim());
    case "buy":
      return console.log(await a.buyMiner(Number(args[1]), Number(args[2] ?? 0), Number(args[3] ?? 0)));
    case "upgrade":
      return console.log(await a.upgradeFacility());
    case "sell":
      return console.log(await a.sellMiner(args[1]));
    case "fund": {
      const from = flag("from");
      const amount = flag("amount");
      if (typeof from !== "string" || typeof amount !== "string")
        throw new Error(`usage: bincoin fund --from <${Object.keys(ORIGINS).join("|")}> --amount <ETH> [--to agent|player] [--quote]`);
      if (a.chain.id !== DESTINATION_CHAIN_ID) throw new Error("cross-chain funding works on Robinhood Chain mainnet only; on testnet use the faucet");
      const to = flag("to", "agent");
      if (to !== "agent" && to !== "player") throw new Error("--to must be agent (the AI key, for gas) or player (the wallet that plays)");
      const recipient = to === "agent" ? a.account.address : a.player;
      const r = await fund({
        account: a.account,
        from,
        recipient,
        amount: parseEther(amount),
        rpcUrl: process.env.BINCOIN_FROM_RPC_URL,
        dryRun: !!flag("quote", false),
        onUpdate: (m) => console.log(m),
      });
      console.log(`${r.dryRun ? "quote" : r.status}: ${formatEther(r.send)} ETH from ${r.from} -> ${formatEther(r.receive)} ETH to ${r.to} on Robinhood Chain`);
      return console.log(`fee ≈ $${r.feeUsd.toFixed(2)} · ≈ ${r.seconds}s · Relay request ${r.requestId}`);
    }
    case "auto": {
      const interval = Number(flag("interval", 300)) * 1000;
      const dryRun = !!flag("dry-run", false);
      console.log(`autonomous mode every ${interval / 1000}s${dryRun ? " (dry run)" : ""} - Ctrl+C to stop`);
      gasWarning(await a.status());
      for (;;) {
        try {
          const r = await a.autoStep(policy(), { dryRun });
          const ts = new Date().toISOString();
          for (const x of r.actions) console.log(`${ts} ${x.type}${x.name ? ` ${x.name}` : ""}: ${x.reason}`);
          for (const t of r.results) if (t.hash) console.log(`${ts}   tx ${t.hash}`);
        } catch (e) {
          console.error(new Date().toISOString(), "step failed:", e.shortMessage ?? e.message);
        }
        if (flag("once")) return;
        await new Promise((r) => setTimeout(r, interval));
      }
    }
    default:
      console.log("commands: init [--mode m --player 0x.. --chain id] | address | status [--json] | plan | join [ref] | claim | buy <typeId> [x y] | upgrade | sell <minerId> | fund --from <chain> --amount <ETH> [--to agent|player] [--quote] | auto [--interval s] [--dry-run] [--once] [--allow-eth]");
  }
}

function policy() {
  return {
    minClaimBin: Number(flag("min-claim", 1)),
    reserveBin: Number(flag("reserve", 0)),
    maxPaybackDays: Number(flag("max-payback", 120)),
    allowEthSpend: !!flag("allow-eth", false),
  };
}

main().catch((e) => {
  console.error(e.shortMessage ?? e.message);
  process.exit(1);
});
