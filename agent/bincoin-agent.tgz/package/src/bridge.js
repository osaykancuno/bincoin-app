// Cross-chain funding: bring ETH from another chain (Base, Arbitrum, Optimism, Ethereum, Linea) to Robinhood Chain
// through Relay (https://relay.link), an intents bridge that settles in seconds. Used by `bincoin fund` and the MCP
// tool `bincoin_fund`.
//
// Relay builds the deposit transaction. Before anything is signed, checkDeposit() makes sure it is exactly a native
// ETH deposit of the requested amount into Relay's audited, non-upgradable Depository on the origin chain, made by
// this key, paying out ETH on Robinhood Chain to the requested recipient. A tampered or unexpected quote is refused.
import { createPublicClient, createWalletClient, formatEther, getAddress, http } from "viem";
import { arbitrum, base, linea, mainnet, optimism } from "viem/chains";

export const RELAY_API = process.env.BINCOIN_RELAY_API || "https://api.relay.link";
export const DESTINATION_CHAIN_ID = 4663; // Relay serves Robinhood Chain mainnet only (no testnet route)
const NATIVE = "0x0000000000000000000000000000000000000000";
const DEPOSIT_NATIVE = "0x49290c1c"; // depositNative(address depositor, bytes32 id)

/// Origin chains and Relay's Depository on each (Relay chains API, protocol.v2.depository, checked 2026-10-15)
export const ORIGINS = {
  base: { chain: base, depository: "0x4cd00e387622c35bddb9b4c962c136462338bc31" },
  arbitrum: { chain: arbitrum, depository: "0x4cd00e387622c35bddb9b4c962c136462338bc31" },
  optimism: { chain: optimism, depository: "0x4cd00e387622c35bddb9b4c962c136462338bc31" },
  ethereum: { chain: mainnet, depository: "0x4cd00e387622c35bddb9b4c962c136462338bc31" },
  linea: { chain: linea, depository: "0x59916da825d2d2ec1bf878d71c88826f6633ecca" },
};

export function origin(name) {
  const o = ORIGINS[String(name).toLowerCase()];
  if (!o) throw new Error(`unknown origin chain "${name}": use one of ${Object.keys(ORIGINS).join(", ")}`);
  return o;
}

/// Throws unless the quote is exactly the deposit we asked for. Returns the transaction to sign.
export function checkDeposit(quote, { originChainId, depository, user, recipient, amount }) {
  const steps = quote?.steps ?? [];
  if (steps.length !== 1 || steps[0].kind !== "transaction" || steps[0].items?.length !== 1) throw new Error("bridge: unexpected quote (more than one step)");
  const tx = steps[0].items[0].data ?? {};
  if (Number(tx.chainId) !== originChainId) throw new Error("bridge: quote is for another chain");
  // Relay moving to a new Depository needs a toolkit update before this key trusts it
  if (String(tx.to).toLowerCase() !== depository.toLowerCase()) throw new Error(`bridge: unexpected deposit contract ${tx.to} (update the toolkit)`);
  if (BigInt(tx.value ?? 0) !== amount) throw new Error("bridge: quote sends a different amount");
  const data = String(tx.data ?? "").toLowerCase();
  if (!data.startsWith(DEPOSIT_NATIVE) || data.length !== 10 + 128) throw new Error("bridge: quote is not a plain ETH deposit");
  if (`0x${data.slice(34, 74)}` !== user.toLowerCase()) throw new Error("bridge: deposit made for another address");
  const d = quote.details ?? {};
  if (String(d.recipient ?? "").toLowerCase() !== recipient.toLowerCase()) throw new Error("bridge: quote pays another recipient");
  const out = d.currencyOut ?? {};
  if (Number(out.currency?.chainId) !== DESTINATION_CHAIN_ID || String(out.currency?.address).toLowerCase() !== NATIVE)
    throw new Error("bridge: quote does not pay ETH on Robinhood Chain");
  const requestId = String(steps[0].requestId ?? "");
  if (!/^0x[0-9a-f]{64}$/i.test(requestId)) throw new Error("bridge: quote has no valid request id");
  const received = BigInt(out.amount ?? 0);
  // fees above 5% mean the amount is too small to be worth bridging
  if (received * 100n < amount * 95n) throw new Error(`bridge: fees too high for this amount (receive ${formatEther(received)} of ${formatEther(amount)} ETH)`);
  return {
    to: getAddress(tx.to),
    data: tx.data,
    value: amount,
    requestId,
    received,
    feeUsd: Number(quote.fees?.relayer?.amountUsd ?? 0) + Number(quote.fees?.gas?.amountUsd ?? 0),
    seconds: Number(d.timeEstimate ?? 0),
  };
}

export async function quoteDeposit({ from, user, recipient, amount }) {
  const o = origin(from);
  const r = await fetch(`${RELAY_API}/quote`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      user,
      recipient,
      originChainId: o.chain.id,
      destinationChainId: DESTINATION_CHAIN_ID,
      originCurrency: NATIVE,
      destinationCurrency: NATIVE,
      amount: amount.toString(),
      tradeType: "EXACT_INPUT",
    }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(`bridge: no quote (${j.message ?? r.status})`);
  return { origin: o, ...checkDeposit(j, { originChainId: o.chain.id, depository: o.depository, user, recipient, amount }) };
}

export async function depositStatus(requestId) {
  const r = await fetch(`${RELAY_API}/intents/status/v3?requestId=${requestId}`);
  return (await r.json().catch(() => ({}))).status ?? "unknown";
}

/**
 * Bridge `amount` wei of ETH from `from` to `recipient` on Robinhood Chain, paid by `account` (the AI's key, which must
 * hold the ETH on the origin chain). Waits until Relay reports the ETH delivered.
 */
export async function fund({ account, from, recipient, amount, rpcUrl, dryRun = false, onUpdate = () => {} }) {
  const q = await quoteDeposit({ from, user: account.address, recipient, amount });
  const summary = { from: q.origin.chain.name, to: recipient, send: amount, receive: q.received, feeUsd: q.feeUsd, seconds: q.seconds, requestId: q.requestId };
  if (dryRun) return { ...summary, dryRun: true };
  const transport = http(rpcUrl || undefined);
  const pub = createPublicClient({ chain: q.origin.chain, transport });
  const balance = await pub.getBalance({ address: account.address });
  if (balance <= amount) throw new Error(`the AI key has ${formatEther(balance)} ETH on ${q.origin.chain.name}: it needs ${formatEther(amount)} plus gas there`);
  const wallet = createWalletClient({ chain: q.origin.chain, transport, account });
  const hash = await wallet.sendTransaction({ to: q.to, data: q.data, value: q.value });
  onUpdate(`deposit sent on ${q.origin.chain.name}: ${hash}`);
  await pub.waitForTransactionReceipt({ hash });
  for (let i = 0; i < 100; i++) {
    const status = await depositStatus(q.requestId);
    if (status === "success") return { ...summary, hash, status };
    if (status === "failure" || status === "refund") throw new Error(`bridge ${status}: Relay request ${q.requestId}`);
    await new Promise((r) => setTimeout(r, 3000));
  }
  return { ...summary, hash, status: "pending (check later with the request id)" };
}
