// Settings of the agent, kept in a small env file so the CLI and the MCP server find them from anywhere:
// ~/.bincoin/agent.env by default (BINCOIN_ENV_FILE to move it), plus a .env in the current folder.
// Real environment variables always win over the files.
import { chmodSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join } from "node:path";

export const ENV_FILE = process.env.BINCOIN_ENV_FILE || join(homedir(), ".bincoin", "agent.env");

export function readEnvFile(file = ENV_FILE) {
  if (!existsSync(file)) return {};
  const out = {};
  for (const line of readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m) out[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
  return out;
}

/// fills process.env from ./.env and the agent env file, never overriding what is already set
export function loadEnv() {
  for (const f of [join(process.cwd(), ".env"), ENV_FILE]) {
    for (const [k, v] of Object.entries(readEnvFile(f))) if (process.env[k] === undefined) process.env[k] = v;
  }
}

/// merges `values` into the agent env file, readable by its owner only (it holds the AI's key)
export function writeEnvFile(values, file = ENV_FILE) {
  mkdirSync(dirname(file), { recursive: true });
  const all = { ...readEnvFile(file), ...values };
  writeFileSync(file, `${Object.entries(all).map(([k, v]) => `${k}=${v}`).join("\n")}\n`, { mode: 0o600 });
  try {
    chmodSync(file, 0o600);
  } catch {}
}
