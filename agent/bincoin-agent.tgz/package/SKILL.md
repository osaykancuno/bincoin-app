---
name: mining-with-bincoin
description: Play BinCoin, the Bitcoin-style mining game on Robinhood Chain, as an autonomous agent - check status, claim BIN, buy miners, upgrade facilities, prune unprofitable miners. Use when asked to mine BIN, manage a BinCoin facility, or run a BinCoin agent.
---

# Mining with BinCoin (Robinhood Chain)

BinCoin is a mining game: a facility (grid of slots with a power budget) holds miners (hashrate H/s, power W).
Every second the network emits BIN (0.675/s, halving every 180 days, 21M max), split by hashrate share.
20% of the emission is billed as electricity, split by watts: a miner earns only if its H/W beats the break-even
(`breakEvenEfficiency()` = 20% of the network's average H/W). The bill is charged on the facility's total watts, so a
miner below break-even LOWERS the whole facility's rewards (the total is floored at 0): sell or uninstall it.
The electricity rate can move only 5 points per change, once a week.

## Tools (MCP server `bincoin`)
- `bincoin_status`: always call this first. Amounts are wei strings (18 decimals).
- `bincoin_plan`: the built-in strategy's next actions, with reasons (no transaction).
- `bincoin_auto_step`: execute the plan (claim → sell unprofitable → buy best payback → upgrade if bottlenecked).
- `bincoin_claim`, `bincoin_buy_miner {typeId,x,y}`, `bincoin_upgrade_facility`, `bincoin_sell_miner {minerId}`, `bincoin_join`.
- `bincoin_rules`: economics summary.
- `bincoin_fund {from, amountEth, to?, quoteOnly?}`: mainnet only. Bring ETH from Base / Arbitrum / Optimism / Ethereum /
  Linea through the Relay bridge, from the AI key's own balance there, to the AI key (`agent`, gas) or the player wallet
  (`player`). Call with `quoteOnly: true` first. Capped per call (`BINCOIN_FUND_MAX_ETH`, default 0.05 ETH).

## How to play well
1. Not joined → `bincoin_join` (≈ $5 in ETH; gives a Garage and a free starter miner).
2. Prefer `bincoin_plan` then `bincoin_auto_step`. Override only with a clear reason.
3. Payback = (75% of miner cost) / (net BIN per day). Below ~30 days is great, and ~120 days is the default cap.
4. A miner must fit the facility: free slot, enough watts, inside the grid (x < gridW, y < gridH).
5. Facility upgrades burn BIN and have a 24h cooldown; tiers 5-9 also cost ETH (`allowEthSpend: true`).
6. Selling a miner returns exactly 25% of what was paid (the NFT is burned).
7. Never spend ETH or the user's BIN beyond what they asked; in delegate mode respect the BIN cap.
8. In `tba` mode the NFT holder sets a daily budget (`operatorBudgetLeft()`, in `bincoin_status` as `operatorBudget`):
   a call that would exceed it reverts with `OperatorLimitExceeded`. Wait for the next day instead of retrying.
   Selling a miner counts against it at the miner's price minus the refund: sell only clearly unprofitable miners.
9. A wallet the holder locked for sale (`lockedUntil`) keeps mining; holder-only actions wait until the lock ends.
   If `crossChain` is true, the NFT lives on Ethereum: play exactly the same way. Only the holder can move funds out,
   from Ethereum, so never promise the user a withdrawal from here.
10. Low on gas (`agentEthBalance` near 0)? Use `bincoin_fund` only with ETH the user gave the AI key on another chain,
    and only as much as the game needs.
11. No BIN is being emitted (`network.emissionPerSec` = 0: before the announced start, or after the last era, about
    29.6 years in)? Claim what is owed and wait. Never sell miners because they "earn nothing" right now.

## Safety model
In `delegate` and `tba` modes the agent key is sandboxed on-chain: it can only play, never transfer funds out, and
what it can spend is capped (the delegation's BIN cap, or the agent wallet's daily BIN/ETH budget).
